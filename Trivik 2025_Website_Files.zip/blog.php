<?php include 'header.php' ?>
			<!--================================banner section start ===========================  -->
            <div class="banner-about tran5s wow fadeInUp" style="background: linear-gradient(90deg, #7B7B7B 0%, rgba(84, 81, 81, 0.73) 23.44%, rgba(27, 25, 25, 0.00) 100%), url('images/banner/New Project (19).png') center center no-repeat;">
                <div class="container pt-286 pb-170 md-pt-150 md-pb-90">
                    <div class="row d-flex align-items-center">
                        <div class="text-center">
                            <h2 class="h2 mb-20 md-mb-10 position-relative">Our Blog</h2>
                            <p class=""><a href="" class="">Home - Blog</a></p>
                        </div>
                    </div>
                </div>
            </div>
			<!--================================banner section end ===========================  -->

			<!--================================blog-page start ===========================  -->
			<div class="blog-page mb-130 md-mb-60 tran5s wow fadeInUp">
				<div class="blog-page-rapper pt-90 pb-90 md-pt-40 md-pb-40">
					<div class="container">
						<div class="row">
							<div class="col-lg-8">
								<div class="left-blog">
									<div class="left-one mb-40">
										<div class="card">
											<img src="images/blog/blog_07.png" alt="">
											<div class="card-body">
												<div class="pt-20">
													<img src="images/icon/calendar.svg" alt="" class="">
													<span class="pl-10 fs-14 fw-400">15 Nov, 2023</span>
													<img src="images/icon/comment.svg" alt="" class="pl-10">
													<span class="pl-10 fs-14 fw-400">12 Comment</span>
												</div>
												<div class=""><h6 class="color-one pt-20 fw-700 lh-36"><a href="blog-details.html">Delete Wins the ‘Agency of the Year’ at The Sports</a></h6></div>
												<div class=""><p class="pt-20 fs-17 pb-20">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words</p></div>
												<div class="sm-mb-20">
													<ul class="d-flex align-items-center">
														<li><a href="" class="">Continue Reading <i class="bi bi-chevron-right"></i></a></li>
													</ul>
												</div>
											</div>
										</div>
									</div>
									<div class="left-one mb-40">
										<div class="card">
											<img src="images/blog/blog_08.png" alt="">
											<div class="card-body">
												<div class="pt-20">
													<img src="images/icon/calendar.svg" alt="" class="">
													<span class="pl-10 fs-14 fw-400">15 Nov, 2023</span>
													<img src="images/icon/comment.svg" alt="" class="pl-10">
													<span class="pl-10 fs-14 fw-400">12 Comment</span>
												</div>
												<div class=""><h6 class="color-one pt-20 fw-700 lh-36"><a href="blog-details.html">7 Amazon Seller Mistakes You Should Avoid</a></h6></div>
												<div class=""><p class="pt-20 fs-17 pb-20">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words</p></div>
												<div class="sm-mb-20">
													<ul class="d-flex align-items-center">
														<li><a href="" class="">Continue Reading <i class="bi bi-chevron-right"></i></a></li>
													</ul>
												</div>
											</div>
										</div>
									</div>
									<div class="left-one mb-40">
										<div class="card">
											<img src="images/blog/blog_09.png" alt="">
											<div class="card-body">
												<div class="pt-20">
													<img src="images/icon/calendar.svg" alt="" class="">
													<span class="pl-10 fs-14 fw-400">15 Nov, 2023</span>
													<img src="images/icon/comment.svg" alt="" class="pl-10">
													<span class="pl-10 fs-14 fw-400">12 Comment</span>
												</div>
												<div class=""><h6 class="color-one pt-20 fw-700 lh-36"><a href="blog-details.html">How to Project Manage a Website Build</a></h6></div>
												<div class=""><p class="pt-20 fs-17 pb-20">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words</p></div>
												<div class="sm-mb-20">
													<ul class="d-flex align-items-center">
														<li><a href="" class="">Continue Reading <i class="bi bi-chevron-right"></i></a></li>
													</ul>
												</div>
											</div>
										</div>
									</div>
									<div class="left-one mb-40">
										<div class="card">
											<img src="images/blog/blog_10.png" alt="">
											<div class="card-body">
												<div class="pt-20">
													<img src="images/icon/calendar.svg" alt="" class="">
													<span class="pl-10 fs-14 fw-400">15 Nov, 2023</span>
													<img src="images/icon/comment.svg" alt="" class="pl-10">
													<span class="pl-10 fs-14 fw-400">12 Comment</span>
												</div>
												<div class=""><h6 class="color-one pt-20 fw-700 lh-36"><a href="blog-details.html">How to Build a Strategy with Data digital world</a></h6></div>
												<div class=""><p class="pt-20 fs-17 pb-20">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words</p></div>
												<div class="sm-mb-20">
													<ul class="d-flex align-items-center">
														<li><a href="" class="">Continue Reading <i class="bi bi-chevron-right"></i></a></li>
													</ul>
												</div>
											</div>
										</div>
									</div>
									<div class="left-one sm-mb-40">
										<div class="card">
											<div class="card-body">
												<div class="pt-20">
													<img src="images/icon/calendar.svg" alt="" class="">
													<span class="pl-10 fs-14 fw-400">15 Nov, 2023</span>
													<img src="images/icon/comment.svg" alt="" class="pl-10">
													<span class="pl-10 fs-14 fw-400">12 Comment</span>
												</div>
												<div class=""><h6 class="color-one pt-20 fw-700 lh-36"><a href="blog-details.html">Delete Wins the ‘Agency of the Year’ at The Sports</a></h6></div>
												<div class=""><p class="pt-20 fs-17 pb-20">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words</p></div>
												<div class="sm-mb-20">
													<ul class="d-flex align-items-center">
														<li><a href="" class="">Continue Reading <i class="bi bi-chevron-right"></i></a></li>
													</ul>
												</div>
											</div>
										</div>
									</div>
									<div class="pagination mt-40 md-mb-30">
										<a href="#">1</a>
										<a href="#">2</a>
										<a href="#">3</a>
										<a href="#"><i class="bi bi-chevron-right"></i></a>
									</div>
								</div>
							</div>
							<div class="col-lg-4">
								<div class="right-blog pl-160">
									<div class="blog-search mb-40">
										<form class="search-form position-relative d-flex align-items-center">
											<a href=""><img src="images/icon/search-02.svg" alt=""></a>
											<input type="text" placeholder="Search">
										</form>
									</div>
									<div class="blog-categ mb-30">
										<h6 class="h6 fw-700 mb-30">Categories:</h6>
										<ul>
											<li class="d-flex align-items-center justify-content-between"><span class="">Technology</span><span>(3)</span></li>
											<li class="d-flex align-items-center justify-content-between"><span class="">Digital</span><span>(7)</span></li>
											<li class="d-flex align-items-center justify-content-between"><span class="">Marketing</span><span>(6)</span></li>
											<li class="d-flex align-items-center justify-content-between"><span class="">Personal</span><span>(4)</span></li>
										</ul>
									</div>
									<div class="blog-post mb-40">
										<h6 class="h6 fw-700">Latest Post:</h6>
										<div class="post-one mb-30 d-flex align-items-center">
											<div class=""><img src="images/blog/blog_11.png" alt=""></div>
											<div class="">
												<p class="mb-10">25 Dec 2023</p>
												<h6 class=""><a href="blog-details.html">Digital Advertising 101 Facebook</a></h6>
											</div>
										</div>
										<div class="post-one mb-30 d-flex align-items-center">
											<div class=""><img src="images/blog/blog_12.png" alt=""></div>
											<div class="">
												<p class="mb-10">25 Dec 2023</p>
												<h6 class=""><a href="blog-details.html">Big changes affecting all digital</a></h6>
											</div>
										</div>
										<div class="post-one mb-30 d-flex align-items-center">
											<div class=""><img src="images/blog/blog_13.png" alt=""></div>
											<div class="">
												<p class="mb-10">25 Dec 2023</p>
												<h6 class=""><a href="blog-details.html">8 Great Digital Marketing Blogs</a></h6>
											</div>
										</div>
									</div>
									<div class="blog-taq">
										<h6 class="h6 fw-700 mb-30">Tags:</h6>
										<div class="tag_one">
											<a href="#" class="">Agency</a>
											<a href="#" class="">Creative</a>
											<a href="#" class="">Business</a>
											<a href="#" class="">Blog</a>
											<a href="#" class="">Marketing</a>
											<a href="#" class="">Digital</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--================================blog-page end ===========================  -->

		<?php include 'footer.php' ?>