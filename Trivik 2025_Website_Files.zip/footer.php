	<!--================================ Footer start ===========================  -->
			<footer class="footer tran5s wow fadeInUp">
				<div class="footer_wapper pt-80 md-pt-30 pb-50">
				  <div class="container">
					<div class="footer_content">
					  <div class="row">
						<div class="col-lg-4">
						  <div class="footer_item1">
								<div class="footer_logo pt-80 md-pt-30 pb-50">
								<a href=""><img src="images/logo/logo.png" width="250" height="80"  alt="" class="img-fluid"></a>
								</div>
								<!--<p class="fs-20 color-two pt-30 pb-30">We build on the IT domain expertise and industry knowledge to design sustainable technology solutions.</p>-->
								<!--<span class="fs-22">Discover our app</span>-->
								<!--<div class="app_store pt-30">-->
								<!--	<a href=""><img src="images/footer/footer-01.png" alt="" class="img-fluid"> </a>-->
								<!--	<a href=""><img src="images/footer/footer-02.png" alt="" class="img-fluid"></a> -->
								<!--</div>-->
						  </div>
						</div>
						<div class="col-lg-4">
						  <div class="footer_item2 mt-20 md-mt-30">
							<h6 class="fs-22  color-two opacity-two pb-30 md-pb-10">Quick Links</h6>
							<ul>
							  <li><a href="index.php">Home</a></li>
							  <li><a href="about-us.php">About Us</a></li>
							  <li><a href="service.php">Our Services</a></li>
							  <li><a href="clients.php">Our Clients</a></li>
							  <li><a href="contact.php">Contact Us</a></li>
							</ul>
						  </div>
						</div>
						<!--<div class="col-lg-3">-->
						<!--  <div class="footer_item3 mt-20 md-mt-30">-->
						<!--	<h6 class="fs-22  color-two opacity-two pb-30 md-pb-10">Other Link</h6>-->
						<!--	<ul>-->
						<!--	  <li><a href="#">Faq</a></li>-->
						<!--	  <li><a href="#">Tearm of user</a></li>-->
						<!--	  <li><a href="#">Disclaimer</a></li>-->
						<!--	  <li><a href="#">Privacy  Policy</a></li>-->
						<!--	</ul>-->
						<!--  </div>-->
						<!--</div>-->
						<div class="col-lg-4 mt-20 md-mt-30">
						    <div class="footer_item4">
								<ul>
									
									<li><a href="https://www.linkedin.com/company/trivik-technologies-pvt-ltd/about/"><i class="fab fa-linkedin"></i></a></li>
									
								</ul>
								<p class="pt-30 pb-10 md-pt-10"> <a href="tel:+91 98864 06936">+91 98864 06936 , 
								+91 99722 22882</a></p>
								<p><a class="email-link" href="mailto:info@triviktech.com">info@triviktech.com</a></p>
								<div class="footer-shape mt-20"></div>
								 <span style="font-size: 15px; color: #fff;" > Corporate Office </span>
								<p class="mt-20">602, Block C, 6th Floor, Brigade Rubix, HMT Main Road, Bengaluru - 560 013. India.</p>
						    </div>
						</div>
					  </div>
					</div><!-- main footer end -->
	  
					<div class="row mt-100 md-mt-30">
						<div class="col-lg-12 md-mb-30"><p>© 2024 All Rights Reserved by Trivik Technologies.</p></div>
						<!--<div class="col-lg-3 offset-lg-6">-->
						<!--	<a href="" class="term-policy">Terms of use</a>-->
						<!--	<a href="" class="term-policy">Privacy Policy</a>-->
						<!--</div>-->
					</div>
				  </div>
				</div>
			</footer>
			<!-- ============================== Footer end    ============================ -->
			<button class="scroll-top">
				<i class="bi bi-arrow-up-short"></i>
			</button>

		<!-- Optional JavaScript   -->
			<!-- jQuery first, then Bootstrap JS -->
			<!-- jQuery -->
			<script src="vendor/jquery.min.js"></script>
			<!-- Bootstrap JS -->
			<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
			<!-- circle progress bar -->
			<script src="vendor/circle-progress.min.js"></script>
			<!-- Slick Slider -->
			<script src="vendor/slick/slick.min.js"></script>
			<!-- js Counter -->
			<script src="vendor/jquery.counterup.min.js"></script>
			<!-- jquery.sidebar.min.js -->
			<script src="vendor/jquery.sidebar.min.js"></script>
			<!-- waypoints  -->
			<script src="vendor/jquery.waypoints.min.js"></script>
			<!-- jquery.magnific-popup.min.js -->
			<script src="js/jquery.magnific-popup.min.js"></script>
			<!-- isotope -->
			<script src="vendor/isotope.pkgd.min.js"></script>
			<!-- Nice Select -->
			<script src="vendor/nice-select/jquery.nice-select.min.js"></script>
			<!-- wow js -->
			<script src="vendor/wow.min.js"></script>
			<!-- Theme js -->
			<script src="js/theme.js"></script>
	</body>
</html>