	<?php include 'header.php' ?>
			<!--================================banner section start ===========================  -->
            <div class="banner-about md-pt-50 tran5s wow fadeInUp" style="background: linear-gradient(90deg, #7B7B7B 0%, rgba(84, 81, 81, 0.73) 23.44%, rgba(27, 25, 25, 0.00) 100%), url('images/banner/banner-03.png') center center no-repeat;">
                <div class="container pt-286 pb-170 md-pt-150 md-pb-90">
                    <div class="row d-flex align-items-center">
                        <div class="text-center">
                            <h2 class="h2 mb-20 md-mb-10 position-relative">Contact us</h2>
                            
                        </div>
                    </div>
                </div>
            </div>

			<!--================================banner section end ===========================  -->

			<!--================================about section start ===========================  -->
			<!--================================about section end ===========================  -->

            <!--================================contact form end ===========================  -->
            <div class="contact-form pt-120 md-pt-40 position-relative tran5s wow fadeInUp">
                <div class="contact-form-rapper">
                    <section class="about-three">
                        <div class="container">
                            <div class="row d-flex align-items-center justify-content-center">
                                <div class="text-rapper text-center">
                                    
                                    
                                </div>
                            </div>
                            <div class="my-form position-relative">
                                <form action="send_mail.php" method="post">
                                    <div class="row g-lg-4 ms-auto">
                                        <div class="col-lg-6 mb-60 position-relative">
                                            <input class="input-one" type="text" name="first_name" required>
                                            <span class="input-one-text" data-placeholder="First Name*"></span>
                                        </div>
                                        <div class="col-lg-6 mb-60 position-relative">
                                            <input class="input-one" type="text" name="last_name" required>
                                            <span class="input-one-text" data-placeholder="Last Name*"></span>
                                        </div>
                                        <div class="col-lg-6 mb-60 position-relative">
                                            <input class="input-one" type="email" name="email" required>
                                            <span class="input-one-text" data-placeholder="Your Email*"></span>
                                        </div>
                                        <div class="col-lg-6 mb-60 position-relative">
                                            <input class="input-one" type="text" name="subject">
                                            <span class="input-one-text" data-placeholder="Subject"></span>
                                        </div>
                                        <div class="col-lg-12 mb-60 position-relative">
                                            <textarea class="input-two" name="message" rows="4" required></textarea>
                                            <span class="input-two-text" data-placeholder="Message*"></span>
                                        </div>
                                    </div>
                                    <div class="sent-massage">
                                        <button type="submit" class="custom-btn-one">Send a message</button>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </section>
                </div>
            </div>
            <!--================================contact form end ===========================  -->
            <div class="my-contact pt-120 pb-120 md-pt-100 md-pb-60">
                <div class="container">
                    <div class="row d-flex align-items-center">
                        <div class="col-lg-7">
                            <div class="left-content md-mb-50">
                                <iframe src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d7773.82030516271!2d77.53266874161629!3d13.041390749121515!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1s%23602%2C%20Block%20C%2C%206th%20Floor%2C%20Brigade%20Rubix%2C%20HMT%20Main%20Road%2C%20Bengaluru%20-%20560%20013.%20India.!5e0!3m2!1sen!2sin!4v1717825371668!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                            </div>
                        </div>
                        <div class="col-lg-5">
                            <div class="right-content">
                                <div class="mb-20"><h6>Contact Details</h6></div>
                                <div class="mb-20"><p class=""><i class="bi bi-geo-alt"></i> #602, Block C, 6th Floor, Brigade Rubix, HMT Main Road, Bengaluru - 560 013. India.</p></div>
                                <div class="mb-20"><p class=""><i class="bi bi-telephone"></i> Email: info@triviktech.com</p></div>
                                <div class=""><p class=""><i class="bi bi-envelope-open"></i> Phone: +91 98864 06936, <br> +91 99722 22882</p></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

			<!--================================ Footer start ===========================  -->
				<?php include 'footer.php' ?>