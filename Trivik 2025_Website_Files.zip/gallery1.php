<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="keywords" content="IT, Technology, online bussines, Ecommerce, Shop,Digital Marketing">
		<meta name="description" content="Andeo - Hosting Service HTML5 Template for all kinds of IT, Technology, online bussines, Ecommerce, Shop,website ,Digital Marketing">
      	<meta property="og:site_name" content="Andeo">
      	<meta property="og:url" content="https://sayfurrahaman.com/">
      	<meta property="og:type" content="website">
      	<meta property="og:title" content="Andeo - Creative Digital Marketing  HTML5 Template">
		<meta name="og:image" content="images/assets/ogg.png">
		<!-- For IE -->
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<!-- For Resposive Device -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<!-- For Window Tab Color -->
		<!-- Chrome, Firefox OS and Opera -->
		<meta name="theme-color" content="#6dbfb8">
		<!-- Windows Phone -->
		<meta name="msapplication-navbutton-color" content="#6dbfb8">
		<!-- iOS Safari -->
		<meta name="apple-mobile-web-app-status-bar-style" content="#6dbfb8">
		<title>Andeo - Creative Digital Marketing  HTML5 Template</title>
		<!-- Favicon -->
		<link rel="icon" type="image/png" sizes="72x33" href="images/fabicon.png">
		<!-- Main style sheet -->
		<link rel="stylesheet" type="text/css" href="css/style.css" media="all">
		<!-- responsive style sheet -->
		<link rel="stylesheet" type="text/css" href="css/responsive.css" media="all">

		<!-- Fix Internet Explorer ______________________________________-->
		<!--[if lt IE 9]>
			<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
			<script src="vendor/html5shiv.js"></script>
			<script src="vendor/respond.js"></script>
		<![endif]-->	
	</head>

	<body>
		<div class="main-page-wrapper">
			<!-- ===================================================
				Loading Transition
			==================================================== -->

			<div id="preloader">
				<div id="andeo-preloader" class="andeo-preloader">
					<div class="animation-preloader">
					  <h1>ANDEO</h1>
					</div>	
				</div>
			</div>

			<!--=========================header html start  1=================================  -->

			<div class="theme-main-menu sticky-menu theme-menu-one theme-menu-two tran5s wow fadeInUp">
				<div class="inner-content">
					<div class="d-flex align-items-center justify-content-between">
						<div class="d-flex logo order-lg-0"><a href="" class="d-block"><img src="images/logo/logo-02.png" alt=""></a></div>
						<div class="right-wiget ms-auto d-lg-flex align-items-center justify-content-center order-lg-3 ">
							 <div class="search-icon" data-bs-toggle="offcanvas" data-bs-target="#offcanvasTop" aria-controls="offcanvasTop"><a href="#"><img src="images/icon/search-02.svg" alt=""></a></div>
							 <div class="grid-icon" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight"><a href="#"><img src="images/icon/grid-02.svg" alt=""></a></div>
							<div class=""><a class="custom-btn-one" href="contact.html">Contact Us</a></div>
						</div>
						 <!-- ================================================
						                      nav bar start
					     ================================================ -->
                         <div class="left-wiget me-auto">
							<nav class="navbar navbar-expand-lg order-lg-2">
							  <button class="navbar-toggler d-block d-lg-none" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
								<span></span>
							  </button>
							  <div class="collapse navbar-collapse" id="navbarNav">
									<ul class="navbar-nav me-auto mb-2 mb-lg-0">
										<li class="nav-item dropdown">
											<a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
											Home
											</a>
											<ul class="dropdown-menu tran3s">
												<li><a class="dropdown-item" href="index.html">Home One</a></li>
												<li><a class="dropdown-item" href="index-02.html">Home Two</a></li>
												<li><a class="dropdown-item" href="index-03.html">Home Three</a></li>
											</ul>
										</li>
										<li class="nav-item">
											<a class="nav-link" href="about-us.html">About Us</a>
										</li>
										<li class="nav-item dropdown">
											<a class="nav-link active dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
											Portfolio
											</a>
											<ul class="dropdown-menu tran3s">
												<li><a class="dropdown-item active" href="case-one.html">Case One</a></li>
												<li><a class="dropdown-item" href="case-two.html">Case Two</a></li>
												<li><a class="dropdown-item" href="case-details.html">Case Details</a></li>
											</ul>
										</li>
										<li class="nav-item dropdown">
											<a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
											Pages
											</a>
											<ul class="dropdown-menu tran3s">
												<li><a class="dropdown-item" href="team.html">Team</a></li>
												<li><a class="dropdown-item" href="contact.html">Contact</a></li>
												<li><a class="dropdown-item" href="faq.html">Faq</a></li>
												<li><a class="dropdown-item" href="404.html">404</a></li>
											</ul>
										</li>
										<li class="nav-item dropdown">
											<a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
											Services
											</a>
											<ul class="dropdown-menu tran3s">
												<li><a class="dropdown-item" href="service.html">Services</a></li>
												<li><a class="dropdown-item" href="service-details.html">Service Details</a></li>
											</ul>
										</li>
										<li class="nav-item dropdown">
											<a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
											Blog
											</a>
											<ul class="dropdown-menu tran3s">
												<li><a class="dropdown-item" href="blog.html">Blog</a></li>
												<li><a class="dropdown-item" href="blog-details.html">Blog Details</a></li>
											</ul>
										</li>
									</ul>
								    <div class="right-wiget md-mt-30 d-flex align-items-center order-lg-3 d-lg-none ">
									   <div class=""><a class="custom-btn-one position-relative" href="contact.html">Contact Us</a></div>
								    </div>
							   </div>
						    </nav>
						</div>
                        <!-- //header nav  -->
					</div>
			    </div>
			</div>

			<!-- =======================header html end===================================== -->

			<!-- ==========================top aside start ==================================================-->
			<div class="top-aside tran3s wow fadeInUp">
				<div class="offcanvas offcanvas-top" tabindex="-1" id="offcanvasTop" aria-labelledby="offcanvasTop">
					<div class="offcanvas-header">
						<button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
					</div>
					<div class="offcanvas-body">
						<div class="search-wrap">
							<form>
								<input type="text" class="main-search-input" placeholder="Search Your Keyword...">
							</form>
						</div>
					</div>
				</div>
			</div>
			<!-- RIGHT GRID  ASIDE -->
			<div class="right-aside tran3s wow fadeInUp">
				<div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasRight" aria-labelledby="offcanvasRight">
					<div class="offcanvas-header">
						<div class="d-flex logo order-lg-0"><a href="" class="d-block"><img src="images/logo/logo.png" alt=""></a></div>
					  <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"><i class="bi bi-x-square-fill"></i></button>
					</div>
					<div class="offcanvas-body">
						<div class="info-widget">
							<h6 class="color-two mb-20">About Us</h6>
							<p class="mb-30">
								We work with forward-thinking companies to craft and produce impactful solutions through website & mobile app experiences.
								You will work closely with skilled Dolor in reprehenderit in voluptate velit esse cillum.
							</p>
						</div>
						<div class="info-widget info-widget2">
							<h6 class="color-two mb-20">Contact Us</h6>
							<p>
								<i class="bi bi-geo-alt"></i>
								3739 Balboa Street, San Francisco, CA 94121</p>
							<p>
								<i class="bi bi-telephone"></i>
								+0989 7876 9865 9
							</p>
							<p>
								<i class="bi bi-envelope-open"></i>
								hello@templatemr.com
							</p>
						</div>
					</div>
				</div>
			</div>
			<!-- RIGHT GRID  ASIDE -->
            <!-- ==========================aside start ==================================================-->

			<!--================================banner section start ===========================  -->
            <div class="banner-about mb-100 md-mb-50 tran5s wow fadeInUp" style="background: linear-gradient(90deg, #7B7B7B 0%, rgba(84, 81, 81, 0.73) 23.44%, rgba(27, 25, 25, 0.00) 100%), url('images/banner/banner-07.png') center center no-repeat;">
                <div class="container pt-286 pb-170 md-pt-150 md-pb-90">
                    <div class="row d-flex align-items-center">
                        <div class="text-center">
                            <h2 class="h2 mb-20 md-mb-10 position-relative">Our Case</h2>
                            <p class=""><a href="" class="">Our Case</a></p>
                        </div>
                    </div>
                </div>
            </div>
			<!--================================banner section end ===========================  -->
            <!--================================case study section start ===========================  -->
		     <section class="case_study-_one mb-100 lg-mb-80 tran5s wow fadeInUp">
				<div class="container-fluid">
					<div class="case_study_rapper">
						<div class="text-center mb-80 md-mb-50">
							<div class=""><span class="span-two">NEW CASE STUDIES</span></div>
							<div class=""><h4 class="h4 fw-700 position-relative">We Are Passionate About Our <br> Clients And Our Work.</h4></div>
						</div>
						<div class="row">
							<div class="col-lg-3 col-md-4">
								<div class="case-one mb-30 md-mb-30 position-relative">
									<a href="images/case/case_01.png" class="view_pic"><img src="images/case/case_01.png" alt="" class=""></a>
									<div class="shapes hover-box">
										<span class="span-two">Strategy</span>
										<h6 class="h6"><a href="case-details.html" class="">Digital Experience Development Case</a></h6>
									</div>
								</div>
                                <div class="case-one md-mb-30 position-relative">
									<a href="images/case/case_11.png" class="view_pic"><img src="images/case/case_11.png" alt="" class=""></a>
									<div class="shapes hover-box">
										<span class="span-two">Strategy</span>
										<h6 class="h6"><a href="case-details.html" class="">Digital Experience Development Case</a></h6>
									</div>
								</div>
							</div>
							<div class="col-lg-3 col-md-4">
								<div class="case-one mb-30 md-mb-30 position-relative">
									<a href="images/case/case_02.png" class="view_pic"><img src="images/case/case_02.png" alt="" class=""></a>
									<div class="shapes hover-box">
										<span class="span-two">Strategy</span>
										<h6 class="h6"><a href="case-details.html" class="">Digital Experience Development Case</a></h6>
									</div>
								</div>
                                <div class="case-one md-mb-30 position-relative">
									<a href="images/case/case_12.png" class="view_pic"><img src="images/case/case_12.png" alt="" class=""></a>
									<div class="shapes hover-box">
										<span class="span-two">Strategy</span>
										<h6 class="h6"><a href="case-details.html" class="">Digital Experience Development Case</a></h6>
									</div>
								</div>
							</div>
							<div class="col-lg-3 col-md-4">
								<div class="case-one mb-30 md-mb-30 position-relative">
									<a href="images/case/case_03.png" class="view_pic"><img src="images/case/case_03.png" alt="" class=""></a>
									<div class="shapes hover-box">
										<span class="span-two">Strategy</span>
										<h6 class="h6"><a href="case-details.html" class="">Digital Experience Development Case</a></h6>
									</div>
								</div>
                                <div class="case-one md-mb-30 position-relative">
									<a href="images/case/case_13.png" class="view_pic"><img src="images/case/case_13.png" alt="" class=""></a>
									<div class="shapes hover-box">
										<span class="span-two">Strategy</span>
										<h6 class="h6"><a href="case-details.html" class="">Digital Experience Development Case</a></h6>
									</div>
								</div>
							</div>
							<div class="col-lg-3 col-md-4">
								<div class="case-one mb-30 md-mb-30 position-relative">
									<a href="images/case/case_04.png" class="view_pic"><img src="images/case/case_04.png" alt="" class=""></a>
									<div class="shapes hover-box">
										<span class="span-two">Strategy</span>
										<h6 class="h6"><a href="case-details.html" class="">Digital Experience Development Case</a></h6>
									</div>
								</div>
                                <div class="case-one  md-mb-30 position-relative">
									<a href="images/case/case_14.png" class="view_pic"><img src="images/case/case_14.png" alt="" class=""></a>
									<div class="shapes hover-box">
										<span class="span-two">Strategy</span>
										<h6 class="h6"><a href="case-details.html" class="">Digital Experience Development Case</a></h6>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			 </section>	
			<!--================================case study section end ===========================  -->

			<!--================================about section start ===========================  -->
			<section class="about-three mb-90 md-mb-50 position-relative tran5s wow fadeInUp">
				<div class="container">
					<div class="row d-flex align-items-center justify-content-center">
                        <div class="text-rapper text-center">
                            <h4 class="mb-30">An agency like no other. Results to match.</h4>
                            <p>We work with forward-thinking companies to craft and produce impactful solutions through website & mobile app experiences.You will work closely with skilled Dolor in reprehenderit in voluptate velit esse cillum</p>
                        </div>
					</div>
				</div>
			</section>
			<!--================================about section end ===========================  -->

			<!--================================work history start ===========================  -->
			<section class="work-history-one mb-130 lg-mb-60 tran5s wow fadeInUp">
				<div class="container">
					<div class="work-rapper-one pt-60 pb-60">
						<div class="row">
							<div class="col-lg-4">
								<div class="work-one text-center md-mb-30 position-relative">
									<div class=""><h4 class="work heading fw-700 color-two"><span class="counter">10</span>k+</h4></div>
									<div class=""><span class="fw-500 fs-20 upercase">Experienced designers</span></div>
									<div class=""><span class="fs-16 opacity">Our company has 100 expert</span></div>
								</div>
							</div>
							<div class="col-lg-4">
								<div class="work-one text-center md-mb-30 position-relative">
									<div class=""><h4 class="work heading fw-700 color-two"><span class="counter">10</span>k+</h4></div>
									<div class=""><span class="fw-500 fs-20 upercase">SATISFIED CUSTOMERS</span></div>
									<div class=""><span class="fs-16 opacity">Our company satisfied customer</span></div>
								</div>
							</div>
							<div class="col-lg-4">
								<div class="text-center position-relative">
									<div class=""><h4 class="work heading fw-700 color-two"><span class="counter">120</span>k+</h4></div>
									<div class=""><span class="fw-500 fs-20 upercase">COMPLETED CASSES</span></div>
									<div class=""><span class="fs-16 opacity">We have done 1200 Cassses</span></div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!--================================work history end ===========================  -->

			<!--================================ Footer start ===========================  -->
			<footer class="footer tran5s wow fadeInUp">
				<div class="footer_wapper pt-100 md-pt-30 pb-50">
				  <div class="container">
					<div class="footer_content">
					  <div class="row">
						<div class="col-lg-3">
						  <div class="footer_item1">
								<div class="footer_logo">
								<a href=""><img src="images/logo/logo.png" alt="" class="img-fluid"></a>
								</div>
								<h6 class="fs-24 color-two pt-30 pb-30">Say Hello!</h6>
								<span class="fs-22">Discover our app</span>
								<div class="app_store pt-30">
									<a href=""><img src="images/footer/footer-01.png" alt="" class="img-fluid"> </a>
									<a href=""><img src="images/footer/footer-02.png" alt="" class="img-fluid"></a> 
								</div>
						  </div>
						</div>
						<div class="col-lg-3">
						  <div class="footer_item2 mt-20 md-mt-30">
							<h6 class="fs-22  color-two opacity-two pb-30 md-pb-10">Links</h6>
							<ul>
							  <li><a href="about-us.html">About us</a></li>
							  <li><a href="team.html">Meet our team</a></li>
							  <li><a href="case-details.html">Case stories</a></li>
							  <li><a href="blog-details.html">Latest news</a></li>
							  <li><a href="contact.html">Contact</a></li>
							</ul>
						  </div>
						</div>
						<div class="col-lg-3">
						  <div class="footer_item3 mt-20 md-mt-30">
							<h6 class="fs-22  color-two opacity-two pb-30 md-pb-10">Other Link</h6>
							<ul>
							  <li><a href="faq.html">Faq</a></li>
							  <li><a href="about-us.html">Tearm of user</a></li>
							  <li><a href="faq.html">Disclaimer</a></li>
							  <li><a href="service-details.html">Privacy  Policy</a></li>
							</ul>
						  </div>
						</div>
						<div class="col-lg-3 mt-20 md-mt-30">
						    <div class="footer_item4">
								<ul>
									<li><a href=""><i class="fab fa-facebook-f"></i></a></li>
									<li><a href=""><i class="fab fa-instagram"></i></a></li>
									<li><a href=""><i class="fab fa-twitter"></i></a></li>
								</ul>
								<p class="pt-30 pb-10 md-pt-10">( 800 ) 160-616481</p>
								<p><a class="email-link" href="">needhelp@site.com</a></p>
								<div class="footer-shape mt-20"></div>
								<p class="mt-20">185 10h Street, Office 272 Berlin, De 21562</p>
						    </div>
						</div>
					  </div>
					</div><!-- main footer end -->
	  
					<div class="row mt-100 md-mt-30">
						<div class="col-lg-3 md-mb-30"><p>All rights reserved 2023 @mr</p></div>
						<div class="col-lg-3 offset-lg-6">
							<a href="" class="term-policy">Terms of use</a>
							<a href="" class="term-policy">Privacy Policy</a>
						</div>
					</div>
				  </div>
				</div>
			</footer>
			<!-- ============================== Footer end    ============================ -->
			<button class="scroll-top">
				<i class="bi bi-arrow-up-short"></i>
			</button>

			<!-- Optional JavaScript   -->
			<!-- jQuery first, then Bootstrap JS -->
			<!-- jQuery -->
			<script src="vendor/jquery.min.js"></script>
			<!-- Bootstrap JS -->
			<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
			<!-- circle progress bar -->
			<script src="vendor/circle-progress.min.js"></script>
			<!-- Slick Slider -->
			<script src="vendor/slick/slick.min.js"></script>
			<!-- js Counter -->
			<script src="vendor/jquery.counterup.min.js"></script>
			<!-- jquery.sidebar.min.js -->
			<script src="vendor/jquery.sidebar.min.js"></script>
			<!-- waypoints  -->
			<script src="vendor/jquery.waypoints.min.js"></script>
			<!-- jquery.magnific-popup.min.js -->
			<script src="js/jquery.magnific-popup.min.js"></script>
			<!-- Nice Select -->
			<script src="vendor/nice-select/jquery.nice-select.min.js"></script>
			<!-- wow js -->
			<script src="vendor/wow.min.js"></script>
			<!-- Theme js -->
			<script src="js/theme.js"></script>
		</div> <!-- /.main-page-wrapper -->
	</body>
</html>