<?php include 'header.php' ?>
			<!--================================banner section start ===========================  -->
            <div class="banner-about mb-100 md-mb-50 tran5s wow fadeInUp" style="background:linear-gradient(90deg, #332F2F 1.76%, rgba(27, 25, 25, 0.00) 90.06%), url('images/banner/banner-03.png') center center no-repeat;">
                <div class="container pt-286 pb-170 md-pt-150 md-pb-90">
                    <div class="row d-flex align-items-center">
                        <div class="text-center">
                            <h2 class="h2 mb-20 md-mb-10 position-relative">Thank You for Applying </h2>
                            <p class=""><a  class="">We have received your application. Our team will review your details and get in touch if we decide to proceed with your application.</a></p>
                        </div>
                    </div>
                </div>
            </div>

			<!--================================banner section end ===========================  -->

			<!--================================about section start ===========================  -->
		
			
			<?php include 'footer.php' ?>