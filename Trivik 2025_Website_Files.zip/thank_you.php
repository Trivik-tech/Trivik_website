<?php include 'header.php' ?>
			<!--================================banner section start ===========================  -->
            <div class="banner-about mb-100 md-mb-50 tran5s wow fadeInUp" style="background:linear-gradient(90deg, #332F2F 1.76%, rgba(27, 25, 25, 0.00) 90.06%), url('images/banner/banner-03.png') center center no-repeat;">
                <div class="container pt-286 pb-170 md-pt-150 md-pb-90">
                    <div class="row d-flex align-items-center">
                        <div class="text-center">
                            <h2 class="h2 mb-20 md-mb-10 position-relative">Thank You</h2>
                            <p class=""><a  class="">Your message has been sent successfully. We will get back to you shortly. </a></p>
                        </div>
                    </div>
                </div>
            </div>

			<!--================================banner section end ===========================  -->

			<!--================================about section start ===========================  -->
		
			
			<?php include 'footer.php' ?>